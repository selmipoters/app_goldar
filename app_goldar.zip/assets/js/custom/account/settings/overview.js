/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!**************************************************************************************!*\
  !*** ../../../themes/metronic/html/demo1/src/js/custom/account/settings/overview.js ***!
  \**************************************************************************************/


// Class definition
var KTAccountSettingsOverview = function () {
    // Private functions
    var initSettings = function() {

    }

    // Public methods
    return {
        init: function () {
            initSettings();
        }
    }
}();

// On document ready
KTUtil.onDOMContentLoaded(function() {
    KTAccountSettingsOverview.init();
});

/******/ })()
;
//# sourceMappingURL=overview.js.map