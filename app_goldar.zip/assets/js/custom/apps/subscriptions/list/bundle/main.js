/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!************************************************************************************************!*\
  !*** ../../../themes/metronic/html/demo1/src/js/custom/apps/subscriptions/list/bundle/main.js ***!
  \************************************************************************************************/


// On document ready
KTUtil.onDOMContentLoaded(function () {
    KTSubscriptionsList.init();

    // Modals
    KTModalExportCustomers.init();
});
/******/ })()
;
//# sourceMappingURL=main.js.map