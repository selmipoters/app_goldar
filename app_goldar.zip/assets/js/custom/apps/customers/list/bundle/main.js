/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!********************************************************************************************!*\
  !*** ../../../themes/metronic/html/demo1/src/js/custom/apps/customers/list/bundle/main.js ***!
  \********************************************************************************************/


// On document ready
KTUtil.onDOMContentLoaded(function () {
	KTCustomersListTable.init();
    KTModalExportCustomers.init();
});
/******/ })()
;
//# sourceMappingURL=main.js.map