<?php
// Panggil data tampilan dari controller
if ($content) {
    echo view($content);
}
